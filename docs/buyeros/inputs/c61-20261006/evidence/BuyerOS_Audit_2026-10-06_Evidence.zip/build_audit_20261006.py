from pathlib import Path
import csv, json, hashlib, shutil, subprocess, zipfile, sys, datetime, collections, xml.etree.ElementTree as ET
import yaml

ROOT=Path('/workspace/scratch/c5168c1ba5e0')
OUT=ROOT/'audit-20261006'
EV=OUT/'evidence'
DEV=ROOT/'buyeros-dev-audit'
MAIN=ROOT/'buyeros-audit'
BASE='a78859fe474f5722be3755b10e2586436b53bf97'
HEAD='bbaf8ecd1f7ef755b89cdc29c8e01c505ad96442'
STAMP=datetime.datetime.now(datetime.timezone.utc).isoformat()
def csvwrite(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args,cwd=DEV):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()

# Copy only selected evidence. Historical producer evidence stays distinctly labelled.
HIST=EV/'historical-branch-evidence';HIST.mkdir(exist_ok=True)
copy_paths={
 'Q06-replay-results.json':'docs/buyeros/evidence/audit-fixes-20261003/Q11_PR11_CI/q06-traffic-results.json',
 'Q10-local-quality-results.md':'docs/buyeros/evidence/audit-fixes-20261003/Q10_LOCAL/RESULTS.md',
 'Q08-bulk-manifest-results.md':'docs/buyeros/evidence/audit-fixes-20261003/Q08/RESULTS.md',
 'Q09-journey-results.md':'docs/buyeros/evidence/audit-fixes-20261003/Q09/FINAL/RESULTS.md',
 'Q09-mobile-approved-export-fixture.png':'docs/buyeros/evidence/audit-fixes-20261003/Q09/FINAL/celery-continuity-zh-HK-mobile-approved-export-fixture.png',
 'Q05-bulk-mobile-fixture.png':'docs/buyeros/evidence/audit-fixes-20261003/Q05/q05-bulk-zh-mobile.png',
 'N00-neon-contract.md':'docs/buyeros/decisions/2026-10-03-neon-auth-contract.md',
 'Q16-workspace-500.md':'docs/buyeros/incidents/2026-10-03-workspace-500.md',
 'branch-TASKS.json':'TASKS.json',
 'branch-case-status.csv':'docs/buyeros/remaining/AUDIT_FIX_CASE_STATUS_20261003.csv',
}
provenance=[]
for dest,src in copy_paths.items():
    shutil.copyfile(DEV/src,HIST/dest);provenance.append({'copy':str((HIST/dest).relative_to(OUT)),'source_commit':HEAD,'source_path':src,'sha256':sha(HIST/dest),'scope':'historical producer evidence; not a fresh live measurement'})
(EV/'E06-historical-provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')

# Preserve 98 baseline rows unchanged; add independent Oct6 columns.
old=list(csv.DictReader((ROOT/'audit-20261003/BuyerOS_Test_Cases_2026-10-03.csv').open(encoding='utf-8-sig')))
repairs={r['case_id']:r for r in csv.DictReader((HIST/'branch-case-status.csv').open(encoding='utf-8-sig'))}
assert len(old)==98 and set(r['case_id'] for r in old)==set(repairs)
shutil.copyfile(ROOT/'audit-20261003/BuyerOS_Test_Cases_2026-10-03.csv',EV/'baseline-98-cases-20261003.csv')

# Findings preserve Oct3 IDs. Code-level fixes never imply live acceptance.
finding_data=[
('F01','P1','工作區存取與恢復','舊版無會員恢復缺口仍在；本次停於憑證拒絕，未重新驗證會員狀態','恢復 UI 已寫；真實會員／工作區驗收仍受阻','Q01;A26-02','features/live/workspace-picker.tsx','U01;U02'),
('F02','P2','無工作區時不能切換語言','main 未更新，原始限制仍在來源','Q01 已提供本地語言偏好及延後持久化；待部署驗收','Q01;A26-03','features/live/workspace-picker.tsx','U03'),
('F03','P1','成員清單只取首100筆','原始分頁缺口仍在正式來源','20筆分頁、total及搜尋已加入；既有250成員 fixture證據','Q02;A26-03','features/live/member-directory.tsx','U06'),
('F04','P2','成員辨識／入職支援不足','正式來源仍以短ID為主','姓名／完整ID／role編輯已有；只管理現有會員，完整邀請入職流程仍未交付','Q02;A26-02;A26-09','features/live/member-directory.tsx','U07;U08'),
('F05','P1','Operations錯用buyer_id及只顯示首20結果','正式來源未修','改用生成型別id、20筆分頁及舊請求取消；待正式驗收','Q03;A26-03','features/live/operations.tsx','B01'),
('F06','P2','批量分派／確認容易出錯','正式來源仍為原始能力','同事搜尋、精確確認及未知結果保留已有；真人可用性待驗','Q05;A26-03;A26-09','features/live/bulk-actions.tsx','B02;B03;B04;B07;B16'),
('F07','P1','輪詢重抓全部結果及重疊請求','正式來源仍是舊轮詢','摘要輪詢、單一請求、取消、隱藏暫停及退避已有；本次11項poller unit通過','Q06;A26-03;A26-10','services/live/job-poller.ts','B12;B13;P04'),
('F08','P1','研究未知回應重試可能建立新意圖','正式來源未修；未觀察真實重複扣款','穩定fingerprint/key及同意圖retry已有；本次3項intent unit通過','Q04;A26-03','services/live/runs.ts','B05;B06'),
('F09','P2','tone/objective看似控制文案但不改輸出','正式來源仍有誤導風險','改為如實標明免費固定模板，語言只改框架；未新增真實LLM文案能力','Q07;A26-03;A26-09','services/api/buyeros_api/execution/handlers/draft_generate.py','A02;A07'),
('F10','P1','真實研究／聯絡整合及寄送未啟用','研究預設無capability；delivery固定403；核心流程不完整','同樣未啟用；ready提示／責任角色較清晰。不是填API key即可完成','Q11;A26-05;A26-12','services/api/buyeros_api/api/routes/runs.py','R05;O26-02;O26-07;O26-16'),
('F11','P2','一般snapshot只容納1000筆','正式來源無新增manifest','新增上限10000的凍結manifest；10001拒絕、不截斷；0037未確認正式應用','Q08;A26-03','services/api/buyeros_api/services/bulk_manifest.py','B14;B15'),
('F12','P1','真實準確度／現場效能未量測','沒有本次真實provider/goldset/負載證據','離線評估工具已有；假資料分數不代表真實準確度','Q10;A26-10','services/api/tools/evaluate_research_goldset.py','A03;A04;A05;A06;A08;O26-03'),
('F13','P2','狀態文件與實際交付不一致','正式78 operations；開發84；不能混稱已上線','CURRENT_STATUS累積多個Current；PR內文Draft已過時但平台已merged至非main','Q11;A26-01','docs/buyeros/CURRENT_STATUS.md','R05;O26-15'),
('F14','P2','每日工作台／手機／審核效率不足','正式版仍是原始流程；本次登入後未實測','已有中英／鍵盤／手機fixture證據，但長表單、UUID、source段落offset仍增加員工負擔','Q09;A26-09','features/live/draft-grounding-review.tsx','U09;U10;U11;U12;O26-13'),
('F15','P2','初始化短暫顯示登入未設定','正式來源未更新；本次未量測閃現','新增initializing狀態及明確錯誤；待部署驗收','Q01;A26-03','features/providers/workspace-session.tsx','U04'),
('F16','P1','手改草稿後不能完成來源覆核／審批','正式來源仍缺重核通道','新增不可變人工來源覆核、Unicode段落及精確revision/hash；不等於機器核實語義真偽','Q12;A26-03','services/api/buyeros_api/services/draft_grounding.py','D01;D03'),
('F17','P2','Overview顯示project但failed jobs用workspace範圍','正式來源未修','count、清單、deep link共用JobScope；本次3項query unit通過','Q14;A26-03','services/live/job-query.ts','U15'),
('F18','P1','workspace discovery隨全部工作區線性查詢','每頁仍先掃全部workspace再切頁','reviewed branch也未改；歷史PG16 SQL gate失敗；另有peer Q13聲明但未在本樹','Q13;A26-04','services/api/buyeros_api/api/routes/workspaces.py','P06;P07;O26-12'),
('F19','P2','刷新草稿覆蓋未儲存內容','正式來源未修','Save/Discard/Cancel守衛已有；本次7項guard unit通過','Q15;A26-03','features/live/draft-dirty-guard.tsx','D02'),
('F20','P1','Auth0→Neon Auth仍未完成','本次live實際仍跳Auth0','Neon SDK只供spike；N00尚未完整驗收，N01–N07未在此分支交付','N00–N07;A26-06','docs/buyeros/decisions/2026-10-03-neon-auth-contract.md','NA01;O26-10;O26-11'),
('F21','P1','曾發生workspace API 500，根因未明','保留10月2日OperationalError；本次未重現也未關閉','Q16仍待SQLSTATE等診斷；不得猜是cold-start或pool','Q16;Q17;A26-07;A26-08','docs/buyeros/incidents/2026-10-03-workspace-500.md','R06'),
('F22','P1','已做修復仍未交付到正式使用者','main及正式部署仍a78859f','PR11已合併到codex/n00-native-ipc-isolation；相同樹不在main；部署缺口確認','Q11;A26-01;A26-03;A26-13','TASKS.json','O26-15'),
]
findings=[]
for fid,p,title,prod,dev,tasks,path,cases in finding_data:
    findings.append(dict(finding_id=fid,priority=p,problem=title,production_status=prod,development_status=dev,evidence_state='verified metadata/live' if fid=='F22' else 'code-only + labelled historical fixture evidence',task_ids=tasks,case_ids=cases,source_path=path,source_url=f'https://github.com/YNWAforever/BuyerOS/blob/{HEAD}/{path}',evidence='E01;E02;E03;E04;E06;E07',completion='受阻' if fid in ['F01','F10','F12','F20','F21'] else '待驗收'))
for finding in findings:
    baseline_ids=[r['case_id'] for r in old if finding['finding_id'] in r.get('finding_ids','').split(';')]
    finding['case_ids']=';'.join(baseline_ids+[c for c in finding['case_ids'].split(';') if c.startswith('O26-')])
csvwrite('BuyerOS_Findings_2026-10-06.csv',findings)

task_rows=[
('A26-01','P1','Q11','鎖定整合／部署基準','—','Release owner','中；1–2日','待開始','F13;F22','O26-15','TASKS.json; CURRENT_STATUS.md; .github/workflows/buyeros-ci.yml','確認main、PR基底、release SHA與migration；單一機器可讀狀態含code/CI/deployed/UAT四欄；保留歷史附錄。','PR11 merged至非main、CI樹、production SHA全部對得上；84/78差異列出；無過時Current或Draft結論。','只回退新狀態文件／release候選，不改正式資料。'),
('A26-02','P1','Q01/Q02','恢復授權帳戶驗收及入職路徑','A26-01','Workspace admin + QA','中；存取時間未知','受阻','F01;F04','U01;U02;U07;U08;O26-01','workspace-picker.tsx; member-directory.tsx; api/deps.py','由持有權限者確認正確登入方法與既有issuer/sub、canonical user和指定membership；驗證空狀態支援／重查。邀請未有功能則設明確受控入職runbook。','授權operator/reviewer/admin/viewer各看見正確範圍；錯誤帳戶可恢復；不按相同email自動連結或自行升權。','保留原身份／會員關係；若另獲授權新增測試會員，依可回復流程清理。'),
('A26-03','P1','Q01–Q08/Q12/Q14/Q15','驗收並整合已存在的業務修復','A26-01','Frontend + Backend + QA','高；3–5日，視整合衝突','待驗收','F02;F03;F04;F05;F06;F07;F08;F09;F11;F15;F16;F17;F19;F22','B01–B16;D01–D03;U03;U04;U06;U15;O26-04;O26-05;O26-06','features/live/*; services/live/*; API membership/jobs/drafts/bulk_manifest; alembic0037','按既有Q任務review/reuse，保留session世代、If-Match、idempotency、RLS、未知回應與審批約束；建立可部署preview，同步0037與API/UI契約。勿從零重做或盲目整條spike合併。','選取原98案中本次修復相關案例＋44 unit＋API/worker/契約/build/preview流程過關；100/101/1000/1001/10000/10001邊界、lost-response及revocation有持久化讀回。','回退應用版本或feature gate；0037有資料時禁止盲目downgrade，保留manifest/job/audit再按runbook前向修復。'),
('A26-04','P1','Q13','修復workspace discovery的全租戶掃描','A26-01','Backend/DB','高；2–4日','待開始','F18','P06;P07;O26-12','api/routes/workspaces.py; api/deps.py; db/models.py; benchmark_workspace_directory_case.py','先審查peer Q13是否可重用；以既有canonical user做受限member-first查詢、索引及DB分頁；不得用BYPASSRLS或信任email／JWT role。重新評估是否真的依賴Neon N02，勿無條件等待。','W=1/10/100/1000、actor有1/多個/零會員、runtime非owner/NOBYPASSRLS、revocation即時；SQL<=6且不隨無關W增長；EXPLAIN及p95/錯誤分母留證。','以feature gate回舊查詢；新增索引可保留；身份與RLS不可回退成放寬。'),
('A26-05','P1','F10 provider lane','完成真實研究及聯絡供應商接駁','A26-01','Backend + Integrations','高；5–10日，供應商待選','待開始','F10','O26-02;O26-03;A03–A08','providers/base.py; routes/runs.py; run_admission.py; execution handlers; worker/controller','分開選定search、fit/model、contact adapters；實作selection resolver、已核實pricing/capabilities、配額／預算、status reconciliation及來源保存；先sandbox。只改env key不能關閉此項。','有獲授權隔離provider結果：offer→ICP→admit→queue→persisted buyers/evidence/fit→UI；timeout/429/取消/unknown不重複計費；fixtures不可進production。','關閉該provider及新admission；保留未知hold、已接受operation、outbox及帳目，先對帳再重試。'),
('A26-06','P1','N00–N07','完成Neon Auth兼容、身份遷移及切換','A26-01','Identity + Backend + Frontend','高；5–10日以上，真實目標待驗','進行中','F20','NA01;O26-10;O26-11','Neon contract; auth.ts; api/auth.py/verifier.py; canonical user mapping; deployment wiring','先收斂N00到真實支援的登入/session/token/logout及callback契約；釐清原302失敗與真實OAuth路徑的關係；再N01環境、N02不可變identity映射、N03明確issuer/audience/JWKS/alg verifier、N04session、N05negative/security、N06演練、N07切換。','真實隔離Neon在BuyerOS Vinext/Nitro/Vercel產物通過登入/Google若已配置/重新整理/token/API/logout/過期/撤權；canonical users、歷史owner/approval/audit不變；same-email不自動合併；回退演練完成。','切回已驗證auth路徑；新增identity mapping不刪舊canonical資料，不撤銷無關存取；不把fixture信任值帶進正式。'),
('A26-07','P1','Q16','補足workspace 500診斷','A26-01','SRE + Backend','中；1–2日，歷史證據可能缺失','受阻','F21','R06','incidents/2026-10-03-workspace-500.md; api/errors.py; DB engine logging','同request ID記錄脫敏driver類別、SQLSTATE、connection/pool wait/timeout、schema及role版本；歷史無資料則隔離受控重現，先調查才修。','能用同版本證據區分連線、pool、schema／role、驗證原因；無DSN、token、SQL參數或個資外洩。','關閉新增診斷或回退logging配置；保留原事故證據。'),
('A26-08','P1','Q17','只修正已證實的500根因','A26-07','Backend/SRE','待根因；估時未定','受阻','F21','R06','由A26-07證据確定的實際故障位置','根因成立後新增能失敗的回歸案例，再修連線／查詢／權限／生命周期的具體原因；禁止猜測式增加retry/pool。','原故障在相同條件被測試覆蓋，修復後通過；冷／熱、故障恢復及錯誤追蹤具體證據。','回退該修復及相容設定；不自動重播結果未知的寫入。'),
('A26-09','P2','Q09/Q02/Q07','縮短每日工作及審核操作','A26-03','Product + UX + Frontend','中；3–5日','待驗收','F04;F06;F09;F14','U09–U12;O26-13','overview.tsx; drafts.tsx; draft-grounding-review.tsx; bulk-manifest.tsx; settings.tsx','角色化今日清單＋準確篩選／數量；sender/技術ID摺疊；來源用名稱／網址／日期卡片；用選取文字拆段代替輸入code-point；manifest以人名/篩選chips/數量呈現，digest保留進階；精確payload約束不變。','至少3位代表員工各完成找待辦、分派、研究失敗恢復、改稿審批、失敗批量重試；記錄耗時／錯誤／求助；390px/桌面/200%/鍵盤/實際screen reader驗收。','UI feature gate或revert元件；不改domain狀態／審批安全條件。'),
('A26-10','P1','Q10','量測真實準確度及效能','A26-04;A26-05','QA + Product + Backend','高；3–5日，標註工時另計','待開始','F07;F12;F18','A03–A08;P04;P06;P07;O26-03;O26-12','quality_metrics.py; evaluate_research_goldset.py; benchmark tools','固定goldset與holdout及三次run；逐來源讀回、公司去重、地區語言、人工雙人標註；preview做冷／熱負載、長清單、並發、poll及批量，產出延遲／SQL／錯誤／成本。','真實樣本與fixture分開；n、時間、資料量、role、機器、SQL、p50/p95、錯誤分母和成本齊備；p99不足樣本標不穩定；事前門檻全數簽核。','停測並關閉測試負載；不改正式配額／價錢／資料；隔離資料按runbook清理。'),
('A26-11','P1','Q11 final staff gate','完整八模組研究至授權匯出驗收','A26-02;A26-03;A26-04;A26-05;A26-06;A26-09;A26-10','QA + Staff owner','高；2–3日','受阻','F01;F10;F12;F14;F20;F22','O26-01–O26-14','八模組＋API＋DB＋worker/controller＋export/outcomes','用同一隔離dataset，operator建offer/ICP、research、buyers/review/contact、draft/edit；reviewer re-ground→exact approval→export；operator append outcome；admin看readiness/bulk/audit；最後重開讀回。','每段有UI/請求ID/DB或job狀態/worker/provider receipt/匯出對照；角色切換和失敗恢复過關；正式唯讀冒煙不等於完整驗收。','停止新工作；保留已接受／未知任務與審計；用測試資料清理runbook。'),
('A26-12','P1','Delivery feature gap','如需站內發送，另交付可追蹤寄送連接器','A26-05;A26-06','Integrations + Product + QA','高；5–10日以上，供應商待選','待開始','F10','O26-07;O26-16','routes/drafts.py disabledDeliveryBoundary; delivery adapter/outbox/webhook 新增','先定義核准收件人／寄件身份／policy／精確revision驗證；sandbox寄送、穩定message intent、webhook dedupe/signature、bounce/unsubscribe/suppression、unknown對帳。未過關保留403，UI清楚說明目前只匯出。','隔離核准收件人：一次送出、重試不重送、政策撤銷阻擋、事件可追蹤且不偽造送達；新增官方契約與fixture+provider sandbox測試。','關delivery gate並停止新admission；已送出email不可撤回，不回滾成再次寄送。'),
('A26-13','P1','Q11 release','發布同版本候選及持續監控','A26-03;A26-04;A26-11','Release owner + SRE','中；1–2日','待開始','F13;F22','O26-15;R05','CI; Vercel; Alembic; worker runtime selector; status docs','以同一SHA證明CI/preview/schema/queue/provider/Auth及UAT；A26-08事故風險未解不得宣称關閉；站內發送的release另須A26-12。準備可審閱deploy/rollback後依授權發布。','production alias/SHA/API版本/schema/worker epoch讀回一致；登入及read-only smoke成功；監控錯誤與latency；所有未驗項顯示open。','切回上一應用版本／feature gate；資料遷移須相容，不逆向刪manifest或已接受operation。'),
]
tasks=[dict(zip(['task_id','priority','original_task','task','dependencies','owner_role','difficulty_estimate','status','finding_ids','case_ids','locations','implementation','acceptance','rollback'],r)) for r in task_rows]
csvwrite('BuyerOS_Remediation_Tasks_2026-10-06.csv',tasks)

new_specs=[
('O26-01','F01','P1','登入及指定工作區','既有授權帳戶；不得新授權','安全登入→指定/app→核對工作區及role','有效帳戶進入正確範圍；錯誤可恢复','網站顯示Wrong email or password，未進入後台','blocked','live-only','E02'),
('O26-02','F10','P1','Offer→ICP→真實research→buyers/evidence','隔離已核准provider與預算；operator/reviewer','建offer並核准ICP；start run；追queue及DB；比對來源與UI','持久化真實公司／證據／fit及可對帳成本','selected_run_capability預設None；admission503；未執行真實provider','blocked','code-only','E07'),
('O26-03','F12','P1','真實goldset準確度','建議至少50家分層樣本；雙人標註／分歧裁定；固定holdout','三次相同query預算；核對公司、URL、引用及拒答；分語言／市場算分','precision/recall/coverage/abstention/CI及成本，事先接受門檻','只有既有fixture算術工具證據；真實資料未測','not-tested','not-tested','E06'),
('O26-04','F08','P1','研究POST已提交但回應遺失','隔離API/DB或受控unit transport','丟失202回應；double-click；token renewal；路由重開；same-intent retry','相同key/body；持久化1run/1outbox；unknown不盲目新建','本次3 intent unit通過；既有DB證據有1run/1outbox；正式未測','pass-fixture-only','verified','E04;E06'),
('O26-05','F11','P1','10001／10000批量邊界與失敗重試','隔離buyer資料100/101/1000/1001/10000/10001筆','freeze preview→確認→worker50筆chunk；取消／崩潰／50衝突；只重試失敗項','>10000明確拒絕；成功項不重播；exact digest/actor/version及progress正確','本次manifest unit及既有Q08 DB/UI证據；未作正式批量寫入','pass-fixture-only','verified','E04;E06'),
('O26-06','F16;F19','P1','改稿→來源重核→精確審批→下載','隔離有已核准sources/contact/policy；operator/reviewer','改文；Save/Discard/Cancel；reviewer全段重核；approve exact revision；下載比對','改稿不丟失；過期來源不能過關；不同revision不可沿用審批','本次guard7＋grounding units；hosted fixture journey；正式未測','pass-fixture-only','verified','E03;E04'),
('O26-07','F10','P1','目前寄送停用邊界','只在隔離fixture打deliver；正式唯讀','先讀UI能力及routes/drafts.py；fixture嘗試delivery','未有驗證connector時403，不能標示已發送','source固定DELIVERY_DISABLED；hosted journey測403；本次未對正式POST','pass-safety-boundary','code-only + hosted fixture','E03;E07'),
('O26-08','F14','P2','外展後手動結果／修正歷史','隔離已核准匯出；operator','記reply→append correction meeting→refresh／locale切換','append-only歷史保留；UI數量及結果一致','hosted daily workbench JUnit8 pass；正式尚未操作','pass-fixture-only','verified','E03'),
('O26-09','F01;F04','P1','角色／租戶／撤權負向測試','兩租戶、operator/reviewer/admin/viewer、可回復隔離身份','切角色；異租戶ID；撤權後舊tab／重放key；最後admin競爭','403/404無資料漏出；server現行role/RLS檢查；最後admin保留','API812 hosted整體通過，但本次未逐812案映射或正式負測','not-tested-live','blocked','E03'),
('O26-10','F20','P1','Neon canonical身份映射不改歷史actor','隔離Neon及受審閱mapping','old issuer/sub→canonical user→Neon identity；同email異subject；rollback','歷史owner/approval/audit user id穩定；不按email自動合併','production Auth0；本分支未交付N02等正式migration','blocked','code-only','E07'),
('O26-11','F20','P1','Neon真實callback/session/token/API','獲授權隔離Auth target；BuyerOS實際部署產物','登入→callback→reload→session/token→API→logout→expiry/revocation','正確cookies/CSRF/state/trust/role；無fixture信任值；同版可重現','N00 fixture進展存在；原302診斷與真實provider路徑尚待收斂；無real Neongate','blocked','code-only + historical','E06;E07'),
('O26-12','F18','P1','workspace discovery scaling','非owner且NOBYPASSRLS，W=1/10/100/1000；暖樣本>=30、冷樣本另計','同actor1會員；實測SQL、EXPLAIN、p50/p95、errors；多會員分頁與撤權','建議沿用<=6SQL且無關W不影響；p99不足標unstable','歷史SQL4/22/202/2002不過關；本次核對source未改，未重跑PG','fail-historical-still-open','code-only + historical measurement','E06;E07'),
('O26-13','F14','P2','員工日常五任務可用性','至少3位代表員工；桌面/390px/200%/鍵盤/screen reader','找待辦、分派、研究恢復、改稿審批、failed-only批量重試','記完成率、耗時、中斷、求助；建議至少90%無協助、零資料丟失（待產品簽核）','檢視既有手機fixture圖片；本次未做真人／screen reader／登入後互動','not-tested-human','blocked','E06'),
('O26-14','F01;F10;F14;F20','P1','八模組完整同一dataset驗收','有效身份／會員、同版schema/worker/provider；隔離資料','Overview→Offer→Buyers→Results→Research runs→Drafts→Settings→Operations交叉讀回','從建專案至核准匯出／manual outcome同一資料鏈可重開讀回','本次0/8後台正式模組完成；登入受阻，不得用fixture取代','blocked','blocked','E02'),
('O26-15','F13;F22','P1','release SHA／CI／schema／production一致','可讀GitHub及Vercel metadata','讀main/PR實際狀態/CI checkout tree/deployment alias/schema','業務候選與實際部署對應；文件不把非main合併當上線','PR11 merged至開發基底；CI樹一致；production仍a78859f；schema正式未知','fail-release-gap','verified','E01;E03;E07'),
('O26-16','F10','P1','將來站內寄送及狀態回傳','獲授權provider sandbox／隔離收件人；不得客戶發信','approve exact revision→send twice／timeout→provider status→signed webhook重放／bounce／unsubscribe','一次message intent；無雙寄；政策撤銷阻擋；可追蹤真實狀態','功能未交付，現有delivery403；尚未發送任何email','not-tested-feature-gap','code-only','E07'),
]
case_rows=[]
for r in old:
    rr=repairs[r['case_id']]
    extra={'audit_20261006_scope':'historical baseline preserved; no fresh production acceptance',
           'audit_20261006_result':'blocked-live' if r['case_id']=='U01' else 'not-reexecuted-as-original-case',
           'development_repair_status':rr.get('repair_status',''),
           'development_verification':rr.get('verification_status',''),
           'development_release_status':rr.get('release_status',''),
           'audit_20261006_evidence':'E01;E02;E06; original evidence IDs are historical',
           'audit_20261006_note':'參考O26系列及報告的独立測試紀錄；不得把原actual/result當本次live結果'}
    case_rows.append({**r,**extra})
for cid,fs,pri,scenario,pre,steps,expected,actual,result,state,evidence in new_specs:
    r={k:'' for k in case_rows[0]}
    r.update(case_id=cid,finding_ids=fs,priority=pri,scenario=scenario,preconditions=pre,steps=steps,expected=expected,actual=actual,result=result,evidence_state=state,evidence_ids=evidence,historical_status='new-20261006',environment='按actual明確區分正式read-only／本次unit／hosted／歷史fixture',cleanup='本次無正式資料或外部寄送；未執行案例依隔離runbook清理',owner_role='待分派',audit_20261006_scope='new focused audit case',audit_20261006_result=result,development_repair_status='see finding/task matrix',development_verification=actual,development_release_status='not deployed' if cid!='O26-15' else 'production remains baseline',audit_20261006_evidence=evidence,audit_20261006_note='只計所列證據範圍；不代表正式端到端完成')
    case_rows.append(r)
assert len(case_rows)==114
csvwrite('BuyerOS_Test_Cases_2026-10-06.csv',case_rows)
for task in tasks:
    fids=set(task['finding_ids'].split(';'))
    task['case_ids']=';'.join(r['case_id'] for r in case_rows if fids.intersection(r.get('finding_ids','').split(';')))
csvwrite('BuyerOS_Remediation_Tasks_2026-10-06.csv',tasks)

# A separate UI action inventory preserves role/control/precondition context.
ui_baseline=list(csv.DictReader((ROOT/'audit-20261003/BuyerOS_Operation_Inventory_2026-10-03.csv').open(encoding='utf-8-sig')))
ui_rows=[]
for r in ui_baseline:
    ui_rows.append({**r,'audit_20261006_actual':'公開入口有Sign in' if r['operation_id']=='OP01' else '登入流程被網站拒絕；無signed-in證據' if r['operation_id']=='OP02' else '本次未進入登入後工作區，原actual/result屬歷史',
        'audit_20261006_result':'pass-live' if r['operation_id']=='OP01' else 'blocked-live',
        'audit_20261006_evidence':'E02','audit_scope':'代表性UI操作清單；非每個DOM按鈕均實測'})
for n,section,route,role,action,pre,expected,cases,path in [
 ('UI26-01','Buyers','/app/discover','operator/reviewer','Preview segmented maintenance','目前role允許、1–10000匹配buyer','凍結actor/filter/id/version/digest，不改buyer','O26-05','features/live/bulk-manifest.tsx'),
 ('UI26-02','Buyers','/app/discover','operator/reviewer','Execute confirmed manifest','未過期精確digest/If-Match/confirmation','一次同步結果或一job/outbox；每筆可核對','O26-05','features/live/bulk-manifest.tsx'),
 ('UI26-03','Drafts','/app/outreach','reviewer/admin','Submit source review','儲存edited revision；來源有效；每段分類確認','新immutable revision及source proof；後續仍須exact approval','O26-06','features/live/draft-grounding-review.tsx'),
 ('UI26-04','Settings','/app/settings','workspace_admin','Search/Next members/Save member','目前admin；reason；If-Match','完整分頁、姓名、最後admin及撤權保護','O26-09','features/live/member-directory.tsx')]:
    r={k:'' for k in ui_rows[0]};r.update(operation_id=n,section=section,route=route,role=role,control_action=action,precondition=pre,expected=expected,actual='code-only; reviewed candidate',case_ids=cases,evidence_ids='E07',result='not-tested-live',source_review=path,scope='new branch control',audit_20261006_actual='功能在開發分支；本次未正式操作',audit_20261006_result='blocked-live',audit_20261006_evidence='E02;E07',audit_scope='代表性UI操作清單；非每個DOM按鈕均實測');ui_rows.append(r)
csvwrite('BuyerOS_UI_Actions_2026-10-06.csv',ui_rows)

# Full declared operation inventory: code inventory, not 84 successful runtime tests.
def operations(root):
    doc=yaml.safe_load((root/'docs/buyeros/contracts/openapi.proposed.yaml').read_text())
    return [(p,m.upper(),o['operationId']) for p,v in doc['paths'].items() for m,o in v.items() if m in ['get','post','put','patch','delete']]
base_ops=operations(MAIN);dev_ops=operations(DEV);assert len(base_ops)==78 and len(dev_ops)==84
ops=[]
for path,method,op in dev_ops:
    ops.append(dict(operation_id=op,method=method,path=path,in_production_source_contract=any(x[2]==op for x in base_ops),development_source=HEAD,live_execution='not-tested / authenticated access blocked',evidence_state='code-only declared contract',notes='delivery endpoint intentionally disabled' if op=='disabledDeliveryBoundary' else 'This inventory is not a claim that every operation was independently exercised.'))
csvwrite('BuyerOS_Operation_Inventory_2026-10-06.csv',ops)

# Pin selected source snapshots and explicit line references used by the audit.
source_paths=[
'features/providers/workspace-session.tsx','features/live/workspace-picker.tsx','features/live/overview.tsx','features/live/offer-wizard.tsx','features/live/buyer-results.tsx','features/live/results.tsx','features/live/run-progress.tsx','features/live/drafts.tsx','features/live/draft-dirty-guard.tsx','features/live/draft-grounding-review.tsx','features/live/member-directory.tsx','features/live/settings.tsx','features/live/operations.tsx','features/live/bulk-actions.tsx','features/live/bulk-manifest.tsx','services/live/runs.ts','services/live/job-poller.ts','services/live/job-query.ts','services/api/buyeros_api/api/routes/workspaces.py','services/api/buyeros_api/api/routes/runs.py','services/api/buyeros_api/services/run_admission.py','services/api/buyeros_api/api/routes/drafts.py','services/api/buyeros_api/services/draft_grounding.py','services/api/buyeros_api/services/bulk_manifest.py','services/api/buyeros_api/api/routes/bulk_manifests.py','services/api/buyeros_api/api/routes/health.py','services/api/buyeros_api/providers/base.py','services/api/buyeros_api/api/auth.py','services/api/buyeros_api/execution/handlers/capability_blocked.py','services/api/buyeros_api/execution/handlers/draft_generate.py','services/api/alembic/versions/0037_bulk_manifests.py','tests/e2e/fixtures/staff-journey.ts']
snapshot=EV/'source-reviewed';snapshot.mkdir(exist_ok=True)
source_manifest=[]
for p in source_paths:
    dest=snapshot/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(DEV/p,dest)
    source_manifest.append({'path':p,'source_sha':HEAD,'sha256':sha(dest),'base_same':git('show',f'{BASE}:{p}')==git('show',f'{HEAD}:{p}') if (MAIN/p).exists() else False})
tree=git('rev-parse',HEAD+'^{tree}')
release={'checked_at_utc':STAMP,'main':BASE,'reviewed_development':HEAD,'pr11_base_tip':'05d8a4aad52857ca4388aec4ee338cfbc197372c','ci_checkout':'767f13e1c66321bc8a7e87b590c1795135a8cba4','tree':tree,'ci_tree':git('rev-parse','767f13e1c66321bc8a7e87b590c1795135a8cba4^{tree}'),'merged_tree':git('rev-parse','05d8a4aad52857ca4388aec4ee338cfbc197372c^{tree}'),'source_contract_counts':{'main':len(base_ops),'development':len(dev_ops)},'new_operations':[x[2] for x in dev_ops if not any(y[2]==x[2] for y in base_ops)],'source_manifest':source_manifest,'repository_clean_main':git('status','--porcelain',cwd=MAIN)=='','repository_clean_development':git('status','--porcelain')==''}
assert release['tree']==release['ci_tree']==release['merged_tree']
(EV/'E07-source-and-release.json').write_text(json.dumps(release,ensure_ascii=False,indent=2),encoding='utf-8')

modules=[
('Overview','/app','工作優先次序、失敗工作及用量','Q14正確project範圍已有；其餘卡片仍有通用Operations入口／缺數量，需真人任務驗收','F14;F17;F18'),
('Offer','/app/discover/new；/app/discover/edit','offer→facts→ICP核准→research intent','研究防重複已有；實際provider resolver仍None，不能完成真實研究','F08;F10'),
('Buyers','/app/discover','找公司、證據、人工審核、分派、清單、聯絡資料','同事搜尋／分頁／10k manifest有fixture證據；contact provider未核實啟用','F06;F10;F11'),
('Results','/app/results','結果篩選、成本、manual outcomes／更正、匯出','有hosted workbench fixture；真實結果與成本來源尚未驗收','F12;F14'),
('Research runs','/app/runs','進度、事件、取消、失敗恢復、重開讀回','run subscriber／intent檢查通過；生產search/fit path仍blocked capability','F07;F08;F10'),
('Drafts','/app/outreach','生成→編輯→來源重核→精確審批→授權匯出','固定模板如實標示；dirty/re-ground已有；delivery仍403；長審批表單待簡化','F09;F14;F16;F19'),
('Settings','/app/settings','成員、角色、語言、budget/policy／sender設定','Q01/Q02改善已有；只改現有會員，不等於邀請／Neon身份遷移完成','F01;F02;F03;F04;F20'),
('Operations','/app/operations','能力／readiness、工作及每筆結果、失敗重試、audit','Q03/Q06摘要輪詢與正確分頁已有；provider仍unconfigured/disabled；production schema/worker未讀回','F05;F07;F10;F13;F21'),
]

report=f'''# BuyerOS 網站、後台及研究至外展流程稽核

日期：2026-10-06（UTC；香港 UTC+08:00）。證據整理時間：{STAMP}。範圍：[GitHub](https://github.com/YNWAforever/BuyerOS)、[正式網站](https://buyer-os-nu.vercel.app/) 及指定工作區 `900cd19b-4e03-4446-bdd6-7cb199d96060`。

## 判斷

**目前不能確認整個研究及外展流程可正式使用；根據正式來源，真實研究與站內發送仍未完成接駁。** 開發分支已有大量業務修復及隔離測試證據，但正式站仍部署10月3日稽核時的版本。需要先交付已做修復、完成真實整合及帳戶驗收，才可宣稱整段流程可用。

本次正式後台登入被網站以「Wrong email or password」拒絕，故八個登入後模組 **0/8 完成正式端到端操作**。這是本次存取限制，不能推斷八個模組均故障，也不能把上次無會員問題當成這次再次觀察到的結果。沒有修改產品程式、會員、正式資料、schema或部署，也沒有真實研究消費或寄信。

主要結論：

1. **研究不能只靠填API key解鎖。** `selected_run_capability()`仍回傳`None, production`，`admit_run()`回503 `PROVIDER_UNAVAILABLE`；provider allowlist為空。執行層亦有blocked handler。需完成adapter、選擇器、報價／capability及worker接駁。此結論為程式證據，未在正式帳戶重現POST。[E07]
2. **站內發送未實作成可用交付。** `/drafts/{{id}}/deliver`固定403 `DELIVERY_DISABLED`。已有隔離流程可驗到審批、授權下載及手動記錄結果；沒有證據支持「已自動送出、送達或回覆同步」。停用邊界是正確防護，不能直接刪掉403來完成需求。[E03,E07]
3. **Auth0→Neon Auth未切換。** live仍實際跳Auth0；開發分支的Neon SDK與harness屬兼容spike，production auth檔案仍使用Auth0。N00完整真實兼容及N01–N07遷移仍未完成。[E02,E06,E07]
4. **業務修復有進展但未上線。** 最新CI8個job成功，本次44項重點unit全過；研究重試、成員分頁、批量結果、草稿防遺失、重新來源覆核及10k manifest均已有程式／fixture證據。正式來源未包含這些修復。[E01,E03,E04,E07]
5. **工作區查詢效能問題仍在。** reviewed branch與main的`workspaces.py`相同，每次列舉所有工作區再逐一查membership，最後才切頁。既有實際PG16測量SQL隨W=1/10/100/1000增至4/22/202/2002，沒有通過<=6及不隨無關W增長的門檻。這不是本次正式站latency測量。[E06,E07]

## 版本與證據層次

| 層次 | 本次確認 | 含義 |
|---|---|---|
| main | `{BASE}` | 仍為上次正式來源 |
| production | `dpl_7A95afQdDSUsaPRw2RnPFouQ1hEp`，READY，alias buyer-os-nu.vercel.app，來源main/a78859f | READY只證明部署完成，不等於業務ready |
| reviewed開發head | `{HEAD}` | 稽核其業務修復、測試及未完成Neon spike |
| PR #11 | 2026-10-06 15:20:55Z merged到`codex/n00-native-ipc-isolation`，merge `05d8a4a` | **沒有合併main**；內文仍寫Draft屬過時敘述，採平台實際metadata |
| CI37403378632 | 8/8 jobs success；checkout `767f13e` | git核對其tree、bbaf8ec tree及05d8a4a tree完全一致：`{tree}` |
| contract | main78；開發84 operation IDs | 84是來源清單分母，不是84項正式實測通過 |
| schema | 開發有新增`0037_bulk_manifests` | 正式DB migration head／runtime role／worker selector與epoch本次未讀回 |

開發的原25任務仍保留：Q01–Q08、Q12、Q14、Q15共11項標fixture或integration-fixture verified；Q09/Q10/Q11及N00仍部分完成；Q16根因受阻；N01–N07、Q13、Q17在本checkpoint標outside-current-scope。這是分支狀態聲明，不能轉成正式完成率。另有peer Q13紀錄，**沒有在本次reviewed樹整合**，未獨立驗證其分支。

證據用語：`verified`只適用實際取得的metadata／測試結果；`code-only`為程式可推導行為；`live-only`為當次頁面觀察；`blocked`為缺帳戶／外部驗收條件；`not-tested`不等於通過。歷史圖片、基準與原98案另標，原始actual/result未覆寫。

## 八模組與業務資料鏈

| 模組 | 路由 | 員工目的 | 開發狀態／剩餘工作 | 關聯 |
|---|---|---|---|---|
'''
for m,route,goal,status,ids in modules:report+=f'| {m} | `{route}` | {goal} | {status} | {ids} |\n'
report+='''
以上路由依來源核對；本次未登入後逐頁開啟。正式公開`/`與指定`/app`均只顯示登入入口。[E02]

完整驗收必須追同一組資料：operator建立offer與可用事實 → reviewer核准ICP → operator設定預算並啟動研究 → DB／outbox／worker／provider對帳 → 公司與證據／fit落庫 → 人工審核買家及聯絡人合法用途 → 生成固定模板或已核准model草稿 → 編輯後重新來源覆核 → reviewer審批精確revision、recipient、sender及policy → 授權匯出 → operator追加手動結果／修正；admin在Operations查工作、每筆結果、audit及能力狀態。不能停在按鈕顯示成功。

「完成外展」需分清交付邊界：現有候選支援的是**準備、審批、匯出及手動成果紀錄**。若需求包含站內寄信、bounce／unsubscribe／reply同步，A26-12是新增整合工作，不能以目前fixture journey視為完成。

## F01–F22追蹤

所有原F01–F21保留；新增F22交付缺口。没有任何原問題在本次被標為「正式已驗證完成」。這不否定開發分支的有效修復。

| ID | 優先 | 問題 | reviewed開發狀態 | 後續 |
|---|---|---|---|---|
'''
for r in findings:report+=f"| {r['finding_id']} | {r['priority']} | {r['problem']} | {r['development_status']} | {r['task_ids']} |\n"
report+='''
完整來源路徑、GitHub固定commit連結、正式／開發分欄見 Findings CSV；相關程式快照及hash見E07。P1表示影響核心任務或重要資料／交付，並不代表已證實資安入侵。本次未識別新P0；稽核範圍有限，不能解讀為全面安全保證。

## UI／UX與維護建議

1. **今日待辦要直接帶到待辦資料。** Overview的failed jobs已修範圍，但Pending approvals與Unknown provider acceptance仍通往通用Operations，部分卡片没有數量。改用同一server predicate的數量及篩選deep link；清楚顯示範圍和真正資料更新時間，回到工作台保留工作上下文。[F14/F17]
2. **將「設定」與「今日執行」分開。** 既有手機草稿fixture顯示sender表單、草稿清單、正文、UUID／hash及審批／匯出一路堆疊。已驗證sender應摺疊，預設直接進入待審草稿；修改sender仍建立新版本並使舊審批失效。[E06圖片；F14]
3. **來源覆核使用商業語言。** 新功能要求輸入code-point split position、逐段reason及UUID引用，員工成本高。用選取文字拆段、來源標題／網址／日期／摘錄、清楚的事實／非事實分類；服務端仍校驗Unicode範圍、revision/hash、source版本及完整覆蓋。人工勾選不等於AI已驗證語義真偽。[F16/F14]
4. **批量工具應顯示「對哪些人做甚麼」。** 保留freeze/digest/version，但主要確認畫面顯示買家數、負責同事姓名、操作、篩選、排除數、原因及到期倒數；原始JSON／digest置於技術詳情。提供全筆結果分頁、可下載失敗清單、失敗項重新預覽，而不是重跑全部。[F06/F11]
5. **後台維護減少手動UUID輸入。** 成員姓名搜尋已改善，但邀請／入職仍未形成完整產品流程。當前應提供明確管理員入職runbook／存取申請渠道。後續邀請需綁定不可變identity、workspace及角色，不把email相同當身份相同。[F04/F20]
6. **能力及錯誤狀態要給可執行下一步。** 保留readiness與provider capability的區別；告訴員工「研究未啟用，請聯絡release owner」「可先匯出，站內寄送停用」。錯誤顯示安全request ID、是否可重試及如何保留未儲存內容。[F10/F13/F21]

這些UX問題來自source及明確標示的既有fixture圖片，**未聲稱本次真人可用性或正式手機實测**。建議3位代表員工各跑5項日常任務，記錄完成率、時間、求助次數及資料遺失；90%無協助完成可作提議門檻，須由產品負責人事前確認。實際screen reader與200%完整五任務仍待驗。

## 效能與準確度

### 可核對的既有數據

| 測試 | 條件／來源 | 結果 | 可得結論／限制 |
|---|---|---|---|
| Q06輪詢重播 | 邏輯60秒、10個view、1000筆持久化結果、模擬RTT2500ms，owned PG16／真實HTTP計數 | HTTP1250→140；body bytes9293390→69440；DB executes10000→840；result queries2500→0；每view最大in-flight13→1；全200 | 開發摘要輪詢減少工作量；不是正式wall-clock latency改善百分比；本次僅核對歷史檔案及重跑poller units |
| Q10工作區清單 | owned PG16、runtime非owner/NOBYPASSRLS、1 actor有1會員；每W暖30樣本 | W1/10/100/1000：SQL4/22/202/2002；p95=8.772/35.749/270.364/2822.957ms | 歷史本地門檻失敗，source仍相同；不是production p95；n30 p99不穩定 |
| Q10準確度工具 | 8家fictional公司、holdout6、3次fixture predictions | 有precision/recall/coverage/abstention、Wilson95%及零分母处理 | 只驗算術和結構，不能推斷真實市場準確度 |

### 可直接執行的下一輪測試

- **列表／API**：隔離preview以1k/10k/50k buyer資料測搜尋、篩選、offset/limit與total、CSV內容一致；1/10/50並發，冷啟動另記，穩態10分鐘。至少30暖請求僅作診斷；要談尾延遲應收集足夠樣本並交代環境。提議正常列表p95≤1秒、低錯誤率的實際門檻，由團隊按部署資源事前凍結，不能事後改門檻過關。
- **workspace discovery**：沿用既有<=6SQL且不隨無關W增長的明確門檻；檢查多會員分頁、0會員、inactive會員、撤權、租戶context重用及EXPLAIN。UI的allPages不能掩蓋每頁全租戶掃描。
- **輪詢／恢復**：RTT2.5秒、429含Retry-After、503、timeout、hidden/visible、unmount、A→B→A；每view最多一個在途請求、終態停輪詢、舊資料不回寫。這部分本次已有11項unit通過。
- **批量**：100/101同步異步界線；1000普通snapshot；1001/10000 manifest；10001拒絕且不截斷；50筆chunk中斷及恢復、取消後已提交保留、只重試衝突／失敗項；preview/execute lost-response穩定key且一job/outbox。
- **準確度**：建議至少50家按市場／語言／公司類型分層的雙人標註參考集，holdout與調參分離，3次固定預算重跑；逐公司核對名稱／域名去重、引用是否支持判斷、時效／來源撤銷、wrong-company rate及unknown。報numerator/denominator及區間，不只總分。50只是建議起點，不保證統計效力。
- **成本及結果**：UI usage＝ledger的reserved/settled/released；成功、拒絕、unknown、timeout及取消分列；匯出採相同filter／snapshot／revision，不混用未核准聯絡或草稿。provider receipt與成本日誌要能以operation ID對帳。

本次沒有做正式負載測試、Core Web Vitals/RUM/Lighthouse評分、production p95/p99、真實goldset或paid provider測量；不得把本地／CI數字代入。

## Neon Auth 特別處理

保留用Neon取代Auth0的目標。此repo實際是Vinext/Vite加Nitro Vercel輸出，不能因使用Next API就假設官方Next範例已兼容。分支pin `@neondatabase/auth` 0.5.0-beta作開發依賴；這是repository事實，不是「目前最新版」的聲明。

N00已有SDK／cookie／session／diagnostic JWT及受限transport的fixture進展。文件保留原始302轉送診斷失敗；後續也明確區分Neon provider callback與app callbackURL。因此不能把該診斷單獨當成「真實Google登入必然失敗」，也不能刪去失敗測試而宣稱遷移完成。先以目前官方契約及實際部署runtime確認產品必要路徑，給每項診斷清楚適用性，再做獲授權的隔離Neon驗收。

N01–N07應保留BuyerOS canonical users.id、現有membership/RLS、歷史owner/approval/audit/job actor、Cloudflare HMAC及停用delivery邊界；另建可審阅identity mapping。issuer/audience/JWKS/algorithm取實際授權目標的明確配置，不能套用fictional值或只按email連結。完成migration dry-run、雙身份／角色撤銷負測及回退演練後才切換。

官方背景來源：Neon [新Auth架構說明](https://neon.com/blog/neon-auth-branchable-identity-in-your-database)指出每branch有自己的Auth endpoint及配置／資料，可支援隔離驗證。本次搜尋曾混入legacy Stack Auth內容，未用舊Stack範例作新SDK實作依據；兩個API reference在搜尋工具因text/markdown解析失敗，本報告沒有冒稱已重新讀到其全文。具體SDK契約目前以固定版本repo證據及後續官方原文核對為準。

## 本次測試及覆蓋分母

| 類別 | 實際結果 | 範圍 |
|---|---|---|
| 本次main checks | domain11、live adapter74、auth8、run subscription4，4命令exit0 | 來源a78859f；不等於真實provider或UI驗收 |
| 本次開發重點unit | **44 pass、0 fail、0 error、0 skip** | 10檔：access-denial、bulk-confirmation、manifest、grounding、dirty-guard、job-query、member-contract、profile-read、research-intent、job-poller |
| 初次本地執行 | 37個case pass＋1檔因缺react/jsx-runtime不能載入 | 補repo相同版本React後重跑整組；原tap/XML保留；不是產品失敗或紅綠修復證據 |
| Hosted CI API | **812 pass、101 warnings、263.57s，0fail/error/skip** | 從job112075371676原始log核對；checkout tree等同reviewed head；不是本次本地重新跑API |
| Hosted workflow | **8/8 jobs success** | frontend/api/worker/browser-smoke/browser-zoom/browser-continuity/cloudflare-controller/cloudflare-staff-acceptance；job名staff不等於真人UAT |
| 下載continuity JUnit | research4、workbench8、buyers1、buyer-management3、mvp1，均0fail/error/skip | 5個distinct套件；zip有重複XML副本，不重複累加；不同套件可能重疊情境，不與812或44相加 |
| 正式站 | 公開入口及指定後台登入入口；Auth0錯誤訊息 | 八模組登入後完整驗收0/8；0次真實研究或寄送；沒有正式API操作全覆蓋 |
| 操作清單 | 開發84，main78 | 全數列於inventory；屬source inventory，未作84個production API calls |
| 案例追蹤 | 原98＋本次16＝**114案例** | 原欄保留；新增Oct6觀察欄及O26-01–16。不是114項皆已執行／通過 |

本機沒有可用pytest／已設置隔離PostgreSQL，因此不把本次本地unit說成完整API/DB重跑；hosted證據及歷史PG結果各自標版本和來源。未在稽核中降低任何斷言／增加skip以取得綠燈。

## 優先修復／交付順序

詳細13項任務的修改位置、依賴、角色、估時不確定性、驗收及回退見 Remediation Tasks CSV。估時為供排程討論的工程日範圍，不是交付承諾。

1. **先恢復可驗收狀態**：A26-01鎖版本與分支；A26-02由持權者完成正確帳戶登入／membership核對。已有Q修復進A26-03 review與preview，避免重新開發同一功能。
2. **並行推進互不依賴的核心缺口**：A26-04處理workspace查詢；A26-05真實provider接駁；A26-06 Neon migration。Neon spike未完成不應無限阻塞能独立驗收的業務修復；各lane保留其release gates。
3. **先查明500再修**：A26-07診斷證據 → A26-08針對已證實根因修復。現在不能聲稱F21已解決。
4. **員工可用性與真實品質**：A26-09工作台／審核簡化；A26-10效能／準確度；A26-11同一dataset完成八模組讀回。
5. **站內發送及發布分開驗收**：需要自動寄送時執行A26-12；A26-13以同SHA的CI、preview、schema、Auth/provider/worker及staff UAT為發布證據。沒有可審阅結果前不要求使用者批准模糊部署。

### 交給實作者的執行提示

> 先讀本報告、Findings／Tasks／114案例CSV、原98案、repo AGENTS.md（本次兩checkout未找到）及TASKS.json。重新核對main／candidate／production SHA是否已漂移。保留F與Q/N IDs及所有歷史證據；不把PR內文或CI綠燈當正式完成。先逐項review/reuse已有業務修復，針對核心行為補足驗證；不整批重写。變更session/identity/bulk/approval時必須保留tenant、canonical actor、If-Match、stable intent、unknown hold與exact revision約束。每項回報code、CI、deployed、live/UAT四種狀態，附同版本證據、未解限制及回退。Neon、provider與真實外部發信各按其目標和授權執行；稽核本身不是正式資料修改或寄信授權。

## 證據索引與限制

- E01：GitHub PR/CI metadata及Vercel正式deployment讀回。
- E02：本次公開入口截圖及脫敏登入／runtime觀察；不保存密碼、token或OAuth state。
- E03：最新hosted API log摘錄與下載continuity XML；下載artifact SHA256及XML去重摘要在validation.json。
- E04：本次44 unit的final及首輪環境失敗原始TAP/JUnit。
- E05：本次main四組checks及exit／耗時。
- E06：開發分支既有Q06/Q08/Q09/Q10/N00/Q16證據及來源hash。手機圖僅fixture，不是本次正式操作。
- E07：32個reviewed source檔案快照、hash、CI／合併／head tree一致證明及84 operations inventory。

原10月3日ZIP是追蹤基準，不將其截圖／500／會員狀態重新標成10月6日觀察。本次沒有全repo逐行安全review、所有分支／未提交worktree盤點或正式data/schema巡檢。正式完整流程仍需有效登入帳戶與既有工作區權限；目前可交付的是有證據的部分網站操作＋來源／開發進度稽核及具體後續驗收計劃。
'''
report+=f'\n另附 BuyerOS_UI_Actions_2026-10-06.csv：原{len(ui_baseline)}項代表性UI操作＋4項新控制，共{len(ui_rows)}項；角色、前置條件、期望、歷史結果及本次受阻欄分開。只有公開入口完成live觀察，其餘不能稱為通過。\n'
(OUT/'BuyerOS_Audit_2026-10-06_zhHK.md').write_text(report,encoding='utf-8')

# Render a readable, self-contained HTML report. Images are embedded so it opens standalone.
sys.path.insert(0,str(ROOT/'audit-test-tools/python'))
import markdown,base64
body=markdown.markdown(report,extensions=['tables','fenced_code'])
img=base64.b64encode((EV/'E02-public-entry.jpg').read_bytes()).decode()
html='''<!doctype html><html lang="zh-HK"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>BuyerOS 稽核 2026-10-06</title><style>body{margin:0;background:#f5f7fb;color:#172435;font:16px/1.75 system-ui,-apple-system,"Noto Sans TC",sans-serif}main{max-width:1220px;margin:auto;padding:42px 28px;background:white}h1{font-size:32px;line-height:1.4;border-bottom:5px solid #147d85;padding-bottom:20px}h2{margin-top:44px;font-size:24px;color:#105f67}h3{margin-top:30px}a{color:#0767a2}table{border-collapse:collapse;width:100%;display:block;overflow:auto;font-size:14px;margin:20px 0}td,th{border:1px solid #d7e0e8;padding:10px;vertical-align:top;min-width:90px}th{background:#eaf4f5;text-align:left}tr:nth-child(even){background:#f7fafc}code{font:12px/1.5 ui-monospace,monospace;overflow-wrap:anywhere;background:#f0f3f7;padding:2px 4px}blockquote{border-left:4px solid #147d85;margin:20px 0;padding:4px 20px;background:#eff8f8}figure{margin:30px 0}img{max-width:100%;height:auto;border:1px solid #dae2e9}figcaption{color:#58687c;font-size:13px}li{margin:7px 0}@media print{body,main{background:white}main{padding:0}h2{break-after:avoid}tr{break-inside:avoid}a{color:inherit}table{font-size:10px}td,th{padding:5px;min-width:0}}</style><main>'''+body+f'<figure><img src="data:image/jpeg;base64,{img}" alt="2026-10-06 正式站公開登入入口"><figcaption>E02：本次正式網站桌面登入入口。登入後模組尚未完成實測。</figcaption></figure></main></html>'
(OUT/'BuyerOS_Audit_2026-10-06_zhHK.html').write_text(html,encoding='utf-8')

# Validate row preservation, task DAG, distinct CI suites, fresh tests, and paths.
for before,after in zip(old,case_rows):assert all(after[k]==v for k,v in before.items())
ids={r['task_id'] for r in tasks};graph={r['task_id']:r['dependencies'].split(';') if r['dependencies']!='—' else [] for r in tasks}
def visit(n,trail):
    assert n not in trail
    for dep in graph[n]:assert dep in ids;visit(dep,trail+[n])
for n in ids:visit(n,[])
assert set(r['finding_id'] for r in findings)<=set(';'.join(r['finding_ids'] for r in tasks).split(';'))
j=ET.parse(EV/'E04-unit-tests-final.xml').getroot();assert len(j.findall('.//testcase'))==44 and not any(j.findall('.//'+x) for x in ['failure','error','skipped'])
art=ROOT/'attachments/3054d8fe-67af-4e1b-b069-eadc6478bb1e/buyeros-ci37403378632-continuity.zip'
z=zipfile.ZipFile(art);junit={};dups=[]
for n in z.namelist():
    if n.endswith('.xml'):
        b=z.read(n);digest=hashlib.sha256(b).hexdigest()
        if digest in junit:dups.append({'duplicate':n,'same_as':junit[digest]['path']});continue
        root=ET.fromstring(b);junit[digest]={'path':n,'cases':len(root.findall('.//testcase')),'failures':len(root.findall('.//failure')),'errors':len(root.findall('.//error')),'skips':len(root.findall('.//skipped'))}
validation={'created_utc':STAMP,'original_cases':98,'new_cases':16,'total_cases':114,'findings':22,'tasks':13,'task_dependencies_acyclic':True,'all_findings_mapped':True,'baseline_columns_preserved':True,'main_operations':78,'development_operations':84,'fresh_dev_tests':{'passed':44,'failed':0,'errors':0,'skipped':0},'hosted_artifact_sha256':sha(art),'hosted_artifact_expected_sha256':'460ffc0bb575b5fc87d48e4ea0d742ee1721e0f06d5255d834a2e6f98d4ea9db','hosted_junit_distinct':list(junit.values()),'hosted_junit_duplicates':dups,'source_snapshots':len(source_paths),'signed_in_live_modules_completed':0,'signed_in_live_modules_denominator':8,'product_modified':False}
assert validation['hosted_artifact_sha256']==validation['hosted_artifact_expected_sha256']
assert len(junit)==5
(OUT/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'README.md').write_text('BuyerOS 2026-10-06 audit. Read the zhHK report first. Production main a78859f; reviewed candidate bbaf8ec.\nAll historical evidence and baseline rows are labelled. No claim of successful live authenticated journey.\nNo secrets/OAuth state/passwords or real email transmission included. SHA256SUMS excludes itself and the ZIP.\n',encoding='utf-8')
shutil.copyfile(Path(__file__),OUT/'build_audit_20261006.py')
manifest={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['SHA256SUMS.json','BuyerOS_Audit_2026-10-06_Evidence.zip']}
(OUT/'SHA256SUMS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(OUT/'BuyerOS_Audit_2026-10-06_Evidence.zip','w',zipfile.ZIP_DEFLATED) as zipout:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p.name!='BuyerOS_Audit_2026-10-06_Evidence.zip':zipout.write(p,p.relative_to(OUT))
with zipfile.ZipFile(OUT/'BuyerOS_Audit_2026-10-06_Evidence.zip') as zipout:
    assert zipout.testzip() is None
    for p,d in manifest.items():assert hashlib.sha256(zipout.read(p)).hexdigest()==d
print(json.dumps({'report_bytes':len(report.encode()),'validation':validation,'zip_bytes':(OUT/'BuyerOS_Audit_2026-10-06_Evidence.zip').stat().st_size},ensure_ascii=False))
