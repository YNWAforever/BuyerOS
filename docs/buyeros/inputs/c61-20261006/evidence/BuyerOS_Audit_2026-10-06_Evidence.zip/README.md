BuyerOS 2026-10-06 audit. Read the zhHK report first. Production main a78859f; reviewed candidate bbaf8ec.
All historical evidence and baseline rows are labelled. No claim of successful live authenticated journey.
No secrets/OAuth state/passwords or real email transmission included. SHA256SUMS excludes itself and the ZIP.
