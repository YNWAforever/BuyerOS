# Q16 / F21 — workspace 500 investigation

Status: blocked on underlying diagnostic evidence. Q17 is not unlocked.

Read-only Vercel runtime log inspection in this repair session returned the same audited event for request `1d123054-2633-40b7-8e07-b6aed83dad98`, UTC `2026-10-02T19:40:34Z`, deployment `dpl_7A95afQdDSUsaPRw2RnPFouQ1hEp`, main, GET `/v1/workspaces`, HTTP 500. The preceding configured Auth0 JWKS request returned 200. The only exception detail was `type=OperationalError`.

Query: production, project `prj_qLOzTdqNiKvoS5rBjy5zZ2GeZgMw`, team `ynwaforevers-projects`, request ID above, UTC 19:35–19:45, limit 5. The redacted result is in `../evidence/audit-fixes-20261003/Q16-runtime-log.md`. No configuration or database was changed.

| Hypothesis | Current evidence | Required distinguishing evidence | Conclusion |
|---|---|---|---|
| Driver/connectivity failure | OperationalError only | Driver class, SQLSTATE, timeout classification and connection timing | Unconfirmed |
| Schema/runtime role error | No schema/role readback for this request | Sanitized failing statement category and permission/schema error code | Unconfirmed |
| Neon cold start | No database compute/connection timeline | Matching compute activation and bounded failing/successful connection timeline | Unconfirmed |
| Pool exhaustion | No pool counters or wait timing | Checked-out/wait/timeout counts correlated to this request | Unconfirmed |
| JWT verification failure | JWKS 200; no JWT exception in the supplied log | API verification result correlated by request ID | Not established by this event |
| No workspace membership | Separate subsequent empty access observation | Existing canonical actor and membership readback, under authorization | Separate from the HTTP 500 |

Next evidence owner: SRE / Backend. Obtain sanitized driver error/SQLSTATE, timeout class, connection initialization timing, matching schema/runtime role and pool counters. Do not include DSNs, secrets, SQL parameters or personal identifiers. If those historical details were never recorded, use a separately reviewed bounded diagnostic patch and a controlled reproduction; do not claim a historical cause from a successful retry.

No product patch, guessed pool change, retry, membership grant or Neon migration was made. This documentary investigation needs no artificial RED test. Rollback: revert this document only; preserve the original audit and runtime log evidence.
