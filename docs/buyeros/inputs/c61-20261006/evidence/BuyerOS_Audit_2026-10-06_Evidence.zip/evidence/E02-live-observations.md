# 2026-10-06 正式站觀察（UTC；香港時間 +08:00）

- URL `/` 與指定 `/app?workspace=900cd19b-4e03-4446-bdd6-7cb199d96060` 均顯示 FIMMICK BuyerOS、Sign in to access your workspaces、Sign in。
- 點 Sign in 進入 Auth0 網域 `dev-oaug20cdxqqgn1s8.us.auth0.com`；頁面提供 email/password 及 Google。
- 使用安全登入表單；網站回應 Wrong email or password。沒有讀取或保存憑證值，沒有重試猜測、註冊、重設密碼或改變會員權限。
- 本次沒有正面 signed-in 證據；八個後台模組的正式完整流程均 blocked。這不是八個模組均有故障的證據。
- 公開入口桌面畫面已保存 E02-public-entry.jpg。手機／鍵盤／螢幕閱讀器正式站未測。報告引用的手機圖片另標示為開發分支既有 fixture 證據。
- 公開入口 console 只見一項 chrome-extension 的 metadata 錯誤；不歸因為 BuyerOS 應用程式錯誤。
- Vercel 1 小時日誌樣本（14:39:25–15:39:25 UTC，limit 5）包含 15:23:30 及 15:23:39 的 `/v1/workspaces` Auth0 JWKS HTTP 200 訊息，未提供該 API 的最終回應狀態。不把 JWKS 200 當作登入或工作區成功。
- 該有限樣本沒有新的 OperationalError；不等於全站無錯誤或舊 F21 已修復。首次搜尋字串查詢沒有匹配，已改為同時段不帶全文搜尋的有限樣本。
- 本次未啟動真實研究、付費 provider、聯絡人 enrichment、正式寄送或批量修改；未修改正式 DB／schema／會員／設定／部署。

登入失敗屬本次存取阻礙，不判定為 bot detection，也不歸因為 Neon；正式登入仍是 Auth0。
