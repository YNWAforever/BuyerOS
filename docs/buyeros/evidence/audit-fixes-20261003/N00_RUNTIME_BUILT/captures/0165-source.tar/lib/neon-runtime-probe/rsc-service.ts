// Probe overlay only: deny global fetch before requests reach the official SDK.
import {installProbeFetchGuard} from '@/scripts/neon-runtime-probe.mjs';
installProbeFetchGuard();
export {default} from 'vinext/server/app-router-entry';
