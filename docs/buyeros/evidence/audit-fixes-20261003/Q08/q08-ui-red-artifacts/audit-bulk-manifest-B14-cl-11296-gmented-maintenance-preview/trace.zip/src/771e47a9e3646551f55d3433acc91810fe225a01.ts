import {expect,test} from '@playwright/test';
import {signInWorkbench} from './fixtures/workbench-auth';

test('B14 clipped snapshots have a separate explicit segmented maintenance preview',async({page})=>{
 await signInWorkbench(page,true,'access');
 await page.getByRole('combobox',{name:/^(Language|語言)$/}).selectOption('en');
 await page.getByRole('button',{name:'Buyers',exact:true}).click();
 const buyers=page.getByRole('region',{name:'Buyer results',exact:true});
 await expect(buyers.getByRole('checkbox',{name:/^Select /})).toHaveCount(12);
 await expect(buyers.getByRole('button',{name:'Preview segmented maintenance',exact:true})).toBeVisible();
});
