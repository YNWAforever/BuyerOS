import {getAuth,describeRuntime} from '../../lib/neon-real-runtime/server';
import Client from './client';
export const dynamic='force-dynamic';
export default async function Page(){
 try{const description=describeRuntime();const result=await getAuth().getSession();return <main><h1>N00 session and token diagnostic</h1><p>Protocol experiment only. This subject is not a BuyerOS user ID or workspace role.</p><output data-testid="server-session">{result.error?'session-error':result.data?.user.id??'anonymous'}</output><output data-testid="runtime-fingerprint">{description.fingerprint}</output><Client/></main>;}
 catch{return <main><h1>N00 configuration unavailable</h1><p>The runtime target must be explicitly configured before this experiment can run.</p></main>;}
}
