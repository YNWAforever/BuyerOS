import {test,expect} from '@playwright/test';
import {assertProtocolStorage} from '../../scripts/neon-compatibility-harness.mjs';
test('NA01 runtime flow: real-only diagnostic UI has no build-time Auth configuration',async({page})=>{
 await page.route('**/*',route=>['localhost','127.0.0.1'].includes(new URL(route.request().url()).hostname)?route.continue():route.abort());
 await page.goto('/compat');await expect(page.getByRole('heading',{name:'N00 session and token diagnostic'})).toBeVisible();
 await expect(page.getByTestId('server-session')).toHaveText('anonymous');
 await expect(page.getByRole('button',{name:'Continue with Google'})).toBeEnabled();
 assertProtocolStorage(await page.evaluate(()=>Object.entries(localStorage)));
});
