from urllib.parse import urlsplit

from buyeros_api.services.safe_fetch import is_blocked_host, normalize_url

from ..registry import HandlerResult, register

MAX_DECODED_BYTES = 2 * 1024 * 1024
ALLOWED_CONTENT_TYPES = frozenset({"text/html", "text/plain", "text/markdown", "application/xhtml+xml"})


class FetchRejected(Exception):
    pass


def _reject_if_blocked_host(host: str) -> None:
    try:
        blocked = is_blocked_host(host)
    except ValueError:
        return  # hostname; DNS/IP pinning happens at connection time
    if blocked:
        raise FetchRejected(f"blocked host {host}")


def validate_fetch(url: str, content_type: str, size: int) -> None:
    try:
        normalize_url(url)
    except ValueError:
        raise FetchRejected(f"malformed url: {url}") from None
    parts = urlsplit(url)
    if parts.scheme not in {"http", "https"}:
        raise FetchRejected(f"unsupported scheme {parts.scheme}")
    host = parts.hostname
    if not host:
        raise FetchRejected("missing host")
    _reject_if_blocked_host(host)
    if size < 0 or size > MAX_DECODED_BYTES:
        raise FetchRejected("decoded body size out of range")
    media_type = (content_type or "").split(";")[0].strip().lower()
    if media_type not in ALLOWED_CONTENT_TYPES:
        raise FetchRejected(f"content type {media_type} not allowed")


@register("fetch.evidence")
def handle(session, context, payload) -> HandlerResult:
    """Validate and (in the fetch client) retrieve permitted evidence.

    The live HTTP client is intentionally not wired here: it must run with
    DNS/IP pinning against the deployed egress policy. Validation is enforced
    now so an unsafe URL can never be dispatched.
    """
    if not isinstance(payload, dict):
        return HandlerResult(state="blocked", detail="fetch.evidence: invalid payload")
    url = payload.get("url")
    content_type = payload.get("content_type")
    size = payload.get("size", 0)
    if not isinstance(url, str) or not isinstance(content_type, str):
        return HandlerResult(state="blocked", detail="fetch.evidence: invalid payload")
    try:
        size_value = int(size)
    except (TypeError, ValueError):
        return HandlerResult(state="blocked", detail="fetch.evidence: invalid size")
    try:
        validate_fetch(url, content_type, size_value)
    except FetchRejected as exc:
        return HandlerResult(state="blocked", detail=str(exc))
    return HandlerResult(
        state="blocked",
        detail="fetch.evidence: retrieval and persistence are not configured",
    )
