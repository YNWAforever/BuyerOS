"""Core identity tables: workspaces, users and tenant memberships (BO-005)."""

import uuid

from sqlalchemy import CheckConstraint, DateTime, Boolean, ForeignKeyConstraint, Integer, String, UniqueConstraint, Index, text
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, UUIDPk


class Workspace(Base, UUIDPk):
    __tablename__ = "workspaces"
    __table_args__ = (UniqueConstraint("id", name="uq_workspaces_id"),)

    name: Mapped[str] = mapped_column(String(200), nullable=False)
    controller_scope: Mapped[str | None] = mapped_column(String(200), nullable=True)
    data_mode: Mapped[str] = mapped_column(String(16), nullable=False, default="live")


class User(Base, UUIDPk):
    """A verified OIDC subject. Upserted by immutable (issuer, subject)."""

    __tablename__ = "users"
    __table_args__ = (UniqueConstraint("issuer", "subject", name="uq_users_issuer_subject"),)

    issuer: Mapped[str] = mapped_column(String(255), nullable=False)
    subject: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str | None] = mapped_column(String(200), nullable=True)


class UserIdentity(Base):
    """Exact principal binding; canonical UUID and legacy columns stay unchanged."""
    __tablename__ = "user_identities"
    __table_args__ = (
        ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        CheckConstraint("status IN ('active','revoked')", name="ck_user_identities_status"),
        CheckConstraint("version >= 1", name="ck_user_identities_version"),
    )
    issuer: Mapped[str] = mapped_column(String(255), primary_key=True)
    subject: Mapped[str] = mapped_column(String(255), primary_key=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, server_default="active")
    proof_ref: Mapped[str] = mapped_column(String(200), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False, server_default="1")
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), nullable=False, server_default=text("CURRENT_TIMESTAMP"))


class Membership(Base, TenantMixin):
    """Server-side authority: roles come from here, never from token claims."""

    __tablename__ = "memberships"
    __table_args__ = (
        UniqueConstraint("workspace_id", "id", name="uq_memberships_workspace_id"),
        UniqueConstraint("workspace_id", "user_id", name="uq_memberships_workspace_user"),
        ForeignKeyConstraint(["workspace_id"], ["workspaces.id"], name="fk_memberships_workspace"),
        ForeignKeyConstraint(["user_id"], ["users.id"], name="fk_memberships_user"),
        Index("ix_memberships_active_user_workspace", "user_id", "workspace_id", postgresql_where=text("active IS TRUE")),
    )

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    roles: Mapped[list[str]] = mapped_column(ARRAY(String(32)), nullable=False, default=list)
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)


class WorkspacePreference(Base, TenantMixin):
    """Persisted locale and default markets for one verified member."""

    __tablename__ = "workspace_preferences"
    __table_args__ = (
        UniqueConstraint("workspace_id", "id", name="uq_workspace_preferences_workspace_id"),
        UniqueConstraint("workspace_id", "user_id", name="uq_workspace_preferences_workspace_user"),
        ForeignKeyConstraint(["workspace_id"], ["workspaces.id"], name="fk_workspace_preferences_workspace"),
        ForeignKeyConstraint(["user_id"], ["users.id"], name="fk_workspace_preferences_user"),
    )

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    locale: Mapped[str] = mapped_column(String(5), nullable=False, default="en")
    default_markets: Mapped[list[str]] = mapped_column(ARRAY(String(2)), nullable=False, default=list)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
